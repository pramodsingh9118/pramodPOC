package com.example.genepact.demo.library.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * @author Pramod singh
 *
 */
@Entity
@Table(name= "Tbl_Library")
public class  LibraryEntity {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;	
	
	@Column(name="BookCategory")
	private  String bookCategory;		
	
	
	@Column(name="BookName")
	private String bookName;
		
	@Column(name="LibraryDeposit")
	private  String libraryDeposit;
	
	@Column(name="BookID")
	private int bookID;	//foreign key
	
	@Column(name="Publisher")
	private  String publisher;	

	@Column(name="Subject")
	private  String subject;
	
	@OneToMany(mappedBy = "library", fetch = FetchType.LAZY,  cascade = CascadeType.ALL)
    private Set<BookEntity> books;
	
	
	public LibraryEntity() {
		super();
		// TODO Auto-generated constructor stub
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getBookCategory() {
		return bookCategory;
	}


	public void setBookCategory(String bookCategory) {
		this.bookCategory = bookCategory;
	}


	public String getBookName() {
		return bookName;
	}


	public void setBookName(String bookName) {
		this.bookName = bookName;
	}


	public String getLibraryDeposit() {
		return libraryDeposit;
	}


	public void setLibraryDeposit(String libraryDeposit) {
		this.libraryDeposit = libraryDeposit;
	}


	public int getBookID() {
		return bookID;
	}


	public void setBookID(int bookID) {
		this.bookID = bookID;
	}


	public String getPublisher() {
		return publisher;
	}


	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}


	public String getSubject() {
		return subject;
	}


	public void setSubject(String subject) {
		this.subject = subject;
	}


	public Set<BookEntity> getBooks() {
		return books;
	}


	public void setBooks(BookEntity bookEntity) {
		this.books = (Set<BookEntity>) bookEntity;
	}


	public LibraryEntity(String bookCategory, String bookName, String libraryDeposit, int bookID, String publisher,
			String subject, Set<BookEntity> books) {
		super();
		this.bookCategory = bookCategory;
		this.bookName = bookName;
		this.libraryDeposit = libraryDeposit;
		this.bookID = bookID;
		this.publisher = publisher;
		this.subject = subject;
		this.books = books;
	}


	@Override
	public String toString() {
		return "LibraryEntity [id=" + id + ", bookCategory=" + bookCategory + ", bookName=" + bookName
				+ ", libraryDeposit=" + libraryDeposit + ", bookID=" + bookID + ", publisher=" + publisher
				+ ", subject=" + subject + ", books=" + books + "]";
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((bookCategory == null) ? 0 : bookCategory.hashCode());
		result = prime * result + bookID;
		result = prime * result + ((bookName == null) ? 0 : bookName.hashCode());
		result = prime * result + ((books == null) ? 0 : books.hashCode());
		result = prime * result + id;
		result = prime * result + ((libraryDeposit == null) ? 0 : libraryDeposit.hashCode());
		result = prime * result + ((publisher == null) ? 0 : publisher.hashCode());
		result = prime * result + ((subject == null) ? 0 : subject.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LibraryEntity other = (LibraryEntity) obj;
		if (bookCategory == null) {
			if (other.bookCategory != null)
				return false;
		} else if (!bookCategory.equals(other.bookCategory))
			return false;
		if (bookID != other.bookID)
			return false;
		if (bookName == null) {
			if (other.bookName != null)
				return false;
		} else if (!bookName.equals(other.bookName))
			return false;
		if (books == null) {
			if (other.books != null)
				return false;
		} else if (!books.equals(other.books))
			return false;
		if (id != other.id)
			return false;
		if (libraryDeposit == null) {
			if (other.libraryDeposit != null)
				return false;
		} else if (!libraryDeposit.equals(other.libraryDeposit))
			return false;
		if (publisher == null) {
			if (other.publisher != null)
				return false;
		} else if (!publisher.equals(other.publisher))
			return false;
		if (subject == null) {
			if (other.subject != null)
				return false;
		} else if (!subject.equals(other.subject))
			return false;
		return true;
	}

	
	
}