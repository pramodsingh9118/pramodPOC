package com.example.genepact.demo.library.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.genepact.demo.library.entity.BookEntity;
import com.example.genepact.demo.library.entity.LibraryEntity;
import com.example.genepact.demo.library.repository.LibraryRepository;
import com.howtodoinjava.demo.exception.BookdNotFoundException;

@Service
public class LibrarryService {
     
    @Autowired
    LibraryRepository repository;
    
    
     
    public List<LibraryEntity> getAllBooks()
    {
        List<LibraryEntity> bookList = repository.findAll();
         
        if(bookList.size() > 0) {
            return bookList;
        } else {
            return new ArrayList<LibraryEntity>();
        }
    }
     
    public LibraryEntity getBookById(Long id) throws BookdNotFoundException 
    {
        Optional<LibraryEntity> book = repository.findById(id);
         
        if(book.isPresent()) {
            return book.get();
        } else {
            throw new BookdNotFoundException("No book record exist for given id");
        }
    }
     
    public LibraryEntity createOrUpdateLibrarry(LibraryEntity entity) throws BookdNotFoundException 
    {
    	Optional<LibraryEntity> bookLib = repository.findById((long) entity.getBookID());
         
        if(bookLib.isPresent()) 
        {
        	LibraryEntity newEntity = bookLib.get();
        	
        	LibraryEntity libraryEntity=new LibraryEntity(); 
           
        	libraryEntity.setBookCategory(newEntity.getBookCategory());
        	libraryEntity.setBookName(newEntity.getBookName());  
        	libraryEntity.setLibraryDeposit(newEntity.getLibraryDeposit());
        	libraryEntity.setPublisher(newEntity.getPublisher());
        	libraryEntity.setSubject(newEntity.getSubject());
        	
        
        	BookEntity bookEntity = new BookEntity("java 8", "sunmicrosystem","1111111111111");

            // associate the objects
        	libraryEntity.setBooks(bookEntity);
          
            newEntity = repository.save(libraryEntity);
            
            return newEntity;
        } else {
            entity = repository.save(entity);
             
            return entity;
        }
    } 
     
    public void deleteBookById(Long id) throws BookdNotFoundException 
    {
        Optional<LibraryEntity> book = repository.findById(id);
         
        if(book.isPresent()) 
        {
            repository.deleteById(id);
        } else {
            throw new BookdNotFoundException("No book record exist for given id");
        }
    } 
}